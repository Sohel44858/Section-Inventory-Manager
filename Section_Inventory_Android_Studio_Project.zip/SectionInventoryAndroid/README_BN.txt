SECTION INVENTORY MANAGER — Android Studio Project

এই ZIP-এ Android WebView অ্যাপের source project দেওয়া হয়েছে। এটি APK নয়।

APK বানানোর জন্য:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP Extract করে Android Studio থেকে SectionInventory ফোল্ডার Open করুন।
3. Gradle Sync সম্পন্ন হতে দিন (প্রথমবার ইন্টারনেট লাগতে পারে)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. Build সফল হলে app/build/outputs/apk/debug/app-debug.apk পাওয়া যাবে।

গুরুত্বপূর্ণ:
- অ্যাপের ডেটা ডিভাইসের WebView local storage-এ থাকে।
- এটি এখনো multi-user cloud sync বা server-based role permission দেয় না।
- Android wrapper-এ file picker/backup restore integration এখনো সম্পূর্ণ করা হয়নি।
- Production ব্যবহারের আগে বাস্তব BOM, stock calculation এবং backup/restore পরীক্ষা করুন।
